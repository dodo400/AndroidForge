package com.aibot.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.app.AlertDialog
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(12, 13, 36)
    private val panelBlue = Color.rgb(30, 34, 76)
    private val cyan = Color.rgb(0, 198, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 42)
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(12, 13, 36), Color.rgb(25, 22, 72), Color.rgb(7, 45, 68)))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(20))
        }
        val robot = TextView(this).apply {
            text = "🤖"; textSize = 32f; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(0, 198, 255), Color.rgb(131, 66, 255))).apply { cornerRadius = dp(100).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(68)).apply { marginEnd = dp(14) }
        }
        header.addView(robot)
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(label("AI Bot", 25f, Color.WHITE, true))
        heading.addView(label("●  Online", 14f, Color.rgb(54, 220, 151), false))
        header.addView(heading)
        content.addView(header)

        val welcome = TextView(this).apply {
            text = "Hello! I'm AI Bot, your personal AI assistant.\n\nI can help answer questions, understand your screen, write code, and browse the web.\n\nWhat would you like to do today?"
            textSize = 16f; setTextColor(Color.rgb(235, 243, 255)); setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(18), dp(17), dp(18), dp(17)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(38, 39, 92), Color.rgb(19, 70, 94))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.rgb(69, 102, 174)) }
        }
        content.addView(welcome, matchWrap().apply { bottomMargin = dp(22) })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(featureCard("🎙", "Voice Assistant", Color.rgb(0, 133, 255)) { startVoiceInput() }, weightedCard())
        row1.addView(featureCard("◉", "Understand Screen", Color.rgb(0, 190, 145)) { openAccessibilitySettings() }, weightedCard().apply { marginStart = dp(10) })
        content.addView(row1, matchWrap().apply { bottomMargin = dp(10) })

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(featureCard("▶", "Watch Videos", Color.rgb(126, 42, 238)) { openWebSearch("videos") }, weightedCard())
        row2.addView(featureCard("</>", "Write Code", Color.rgb(245, 151, 18)) { startAssistant() }, weightedCard().apply { marginStart = dp(10) })
        content.addView(row2, matchWrap().apply { bottomMargin = dp(10) })

        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(featureCard("☝", "Screen Actions", Color.rgb(239, 35, 91)) { openAccessibilitySettings() }, weightedCard())
        row3.addView(featureCard("◎", "Browse Website", Color.rgb(0, 174, 164)) { browseWebsite() }, weightedCard().apply { marginStart = dp(10) })
        content.addView(row3, matchWrap().apply { bottomMargin = dp(10) })

        val row4 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row4.addView(featureCard("🌐", "Build Website", Color.rgb(28, 151, 213)) { startAssistantWithPrompt("Help me create a complete responsive website. Ask me for the website purpose if needed, then provide a complete HTML/CSS/JavaScript file that I can save and open in a browser.") }, weightedCard())
        row4.addView(featureCard("📁", "Create & Save Files", Color.rgb(190, 65, 202)) { startAssistantWithPrompt("Help me create a file or code project. Ask what file I need, produce complete file contents, and explain how to save it.") }, weightedCard().apply { marginStart = dp(10) })
        content.addView(row4, matchWrap().apply { bottomMargin = dp(22) })

        val voiceButton = TextView(this).apply {
            text = "🎙  Tap to Speak to AI Bot"; textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(0, 176, 255), Color.rgb(121, 61, 255))).apply { cornerRadius = dp(24).toFloat() }
            setPadding(dp(14), dp(19), dp(14), dp(19))
            contentDescription = "Speak to AI Bot"
            setOnClickListener { startVoiceInput() }
        }
        content.addView(voiceButton, matchWrap().apply { bottomMargin = dp(20) })
        content.addView(label("Speak in English or Hausa. AI Bot can answer aloud and help explain code.", 13f, Color.rgb(145, 177, 211), false).apply { gravity = Gravity.CENTER; setPadding(dp(4), 0, dp(4), dp(18)) })

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(5), dp(10), dp(5), dp(10)); background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(21, 23, 59), Color.rgb(8, 45, 63)))
        }
        listOf("⌂" to "Home", "✣" to "Apps", "◷" to "History", "⚙" to "Settings").forEachIndexed { index, pair ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(2)) }
            item.addView(label(pair.first, 24f, if (index == 0) cyan else Color.LTGRAY, true).apply { gravity = Gravity.CENTER })
            item.addView(label(pair.second, 12f, if (index == 0) cyan else Color.LTGRAY, false).apply { gravity = Gravity.CENTER })
            item.setOnClickListener {
                when (pair.second) {
                    "Apps" -> Toast.makeText(this, "Choose a feature above to get started.", Toast.LENGTH_SHORT).show()
                    "History" -> Toast.makeText(this, "Conversation history is not available yet.", Toast.LENGTH_SHORT).show()
                    "Settings" -> showGeminiSettings()
                }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(nav)
        setContentView(page)
    }


    private fun showGeminiSettings() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API key here"
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(GeminiClient.getApiKey(this@MainActivity))
            setSelection(text.length)
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(label("Your key is saved on this device and used for AI replies.", 14f, Color.LTGRAY, false))
            addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Gemini API Settings")
            .setView(wrap)
            .setPositiveButton("Save", null)
            .setNeutralButton("Test key", null)
            .setNegativeButton("Clear key", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = input.text.toString().trim()
                if (key.isBlank()) { input.error = "Paste your Gemini API key"; return@setOnClickListener }
                GeminiClient.saveApiKey(this, key)
                Toast.makeText(this, "Gemini API key saved on this device.", Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val key = input.text.toString().trim()
                if (key.isBlank()) { input.error = "Paste your Gemini API key"; return@setOnClickListener }
                GeminiClient.saveApiKey(this, key)
                Toast.makeText(this, "Testing Gemini connection…", Toast.LENGTH_SHORT).show()
                GeminiClient.ask(this, "Reply with exactly: Gemini connection successful.") { result ->
                    runOnUiThread {
                        AlertDialog.Builder(this)
                            .setTitle(if (result.contains("Gemini connection successful", true)) "Test successful" else "Test result")
                            .setMessage(result.take(1800))
                            .setPositiveButton("OK", null).show()
                    }
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                GeminiClient.clearApiKey(this)
                input.setText("")
                Toast.makeText(this, "Saved API key cleared.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun featureCard(icon: String, title: String, color: Int, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(6), dp(14), dp(6), dp(14)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color, blendWithDark(color))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.argb(95, 255, 255, 255)) }
            addView(TextView(this@MainActivity).apply { text = icon; textSize = 29f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 14f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0)
            })
            minimumHeight = dp(112)
            isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
    }

    private fun startVoiceInput() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-NG")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-NG")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in English or Hausa")
            }, 41)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                val lower = spoken.lowercase(Locale.ROOT)
                if (lower.startsWith("open ") && (lower.contains(".com") || lower.contains("website"))) {
                    val target = spoken.substringAfter("open ").replace(" website", "").trim()
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (target.startsWith("http")) target else "https://$target"))) }
                    catch (_: Exception) { startAssistantWithPrompt(spoken) }
                } else startAssistantWithPrompt(spoken)
            }
        }
    }

    private fun openAccessibilitySettings() {
        Toast.makeText(this, "Enable AI Bot in Accessibility settings to use screen actions.", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun startAssistant() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startService(Intent(this, FloatingAssistantService::class.java))
    }

    private fun startAssistantWithPrompt(prompt: String) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow Display over other apps, then tap Send again.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingAssistantService::class.java).putExtra("initial_prompt", prompt))
    }

    private fun browseWebsite() { startVoiceInput() }

    private fun openWebSearch(term: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$term")))
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun blendWithDark(color: Int): Int = Color.rgb((Color.red(color) * 0.62).toInt(), (Color.green(color) * 0.62).toInt(), (Color.blue(color) * 0.78).toInt())
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun weightedCard() = LinearLayout.LayoutParams(0, -2, 1f)
}
