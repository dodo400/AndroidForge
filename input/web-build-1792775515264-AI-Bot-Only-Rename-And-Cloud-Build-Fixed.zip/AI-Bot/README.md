# AI Bot for Android

An Android assistant starter project with an English-language dashboard inspired by the supplied reference image. The dashboard includes a colorful gradient design, Voice Assistant, Understand Screen, Watch Videos, Write Code, Screen Actions, Browse Website, Build Website, Create & Save Files, and bottom navigation. The movable floating assistant opens a right-side panel with quick actions and chat.

## Build the APK (multiple options)

### Option 1: Build in the cloud (works from a phone)

1. Upload this project to a GitHub repository, keeping the `.github/workflows/android.yml` file in place.
2. In GitHub, open **Actions** and choose **Build AI Bot APK**.
3. Tap **Run workflow** (or push to the `main` or `master` branch).
4. When the run succeeds, open that run and download the **AI-Bot-APK** artifact. Extract it to get `app-debug.apk`.

The workflow installs Java 17, Android SDK tools, and Gradle 8.9 automatically, then builds and uploads the APK.

### Option 2: Android Studio

1. Open the `AI-Bot` project folder in Android Studio.
2. Use JDK 17 and install Android SDK Platform 35 in SDK Manager.
3. Sync Gradle, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The Android app label and launcher name are `AI Bot`. The Android package/application ID is `com.aibot.app`.

## Enable AI replies

1. Create or open `local.properties` in the project root.
2. Add `GEMINI_API_KEY=your_key_here`.
3. Sync Gradle and rebuild the app.

Keep API keys private. Do not commit `local.properties` or distribute an APK containing a personal API key. For production, route requests through a backend so the key is not exposed in the APK. The current Gemini model/endpoint and Google Search grounding availability may need updating if Google changes API availability or model access. Search citations appear only when the API response includes grounding metadata.

## Permissions and manual setup

- **Display over other apps:** required for the floating bubble and side panel.
- **Accessibility:** required for the explicit Understand Screen action. Screen text is read only after the user chooses that action; this project does not continuously upload screen content.
- **Microphone / speech recognition:** voice input depends on Android's speech-recognition provider and device permissions.
- **Internet:** required for Gemini replies and web links.

## Implemented in this source

- English dashboard labels and app name `AI Bot`.
- Movable floating bubble and right-side overlay panel with close control.
- Microphone-first voice requests in the floating panel and on the dashboard.
- Spoken AI replies using Android TextToSpeech when a Gemini API key is configured.
- Basic voice shortcuts for Back, Understand Screen, and opening YouTube or a spoken website.
- Chat requests through the Gemini client when an API key is configured.
- Google Search grounding is requested for current information, and source URLs are shown when the API returns grounding citations. Supports Hausa and English prompts.
- Website/code generation prompts tuned for complete HTML/CSS/JavaScript and named files.
- Save Last Answer writes the most recent answer to Android Downloads as `.html` when it looks like HTML, otherwise `.txt`.
- Colorful gradient dashboard, feature cards, and floating panel.

## Remaining limitations

- A successful APK build still needs to be confirmed by running the cloud workflow or Android Studio build.
- Conversation history is not persisted.
- Save Last Answer saves the response text as a file; it does not automatically create a full multi-file project or publish/host a website. Generated code should be reviewed and tested.
- Screen understanding extracts accessible on-screen text; it does not interpret screenshots/images or reliably read protected/system surfaces.
- This starter supports a basic Back action through Accessibility when enabled. It does not automatically edit code inside another app, undo arbitrary edits, or provide full screen-control workflows. For safe code edits, an editor/project integration would need to be built. Use Android accessibility features only with explicit user awareness and permission.
- Production-grade API-key protection requires a backend service.


## Gemini API key settings (updated)

Open AI Bot and tap **Settings** in the bottom navigation. Paste your Gemini API key and tap **Save**. Use **Test key** to test the connection or **Clear key** to remove the saved key. The key is stored in this app's private SharedPreferences on the device; it is not embedded in the updated source at build time. For a publicly distributed app, a secure backend is preferable to storing API keys on client devices.
