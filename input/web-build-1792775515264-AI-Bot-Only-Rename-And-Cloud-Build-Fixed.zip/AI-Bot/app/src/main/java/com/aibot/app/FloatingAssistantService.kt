package com.aibot.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Environment
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class FloatingAssistantService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var answerView: TextView? = null
    private var listening = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var micButton: TextView? = null
    private var busy = false
    private val navy = Color.rgb(13, 14, 39)
    private val card = Color.rgb(34, 35, 82)
    private val cyan = Color.rgb(0, 178, 255)
    private var lastAnswer: String = ""
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US }; showBubble() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val initialPrompt = intent?.getStringExtra("initial_prompt")
        if (!initialPrompt.isNullOrBlank()) {
            if (panel == null) togglePanel()
            processPrompt(initialPrompt)
        }
        return START_STICKY
    }
    private fun overlayType() = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply { text = "✦"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = round(cyan, 100); elevation = dp(8).toFloat(); contentDescription = "Open AI Bot" }
        val p = WindowManager.LayoutParams(dp(58), dp(58), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(8); y = dp(220) }
        var sx=0; var sy=0; var tx=0f; var ty=0f
        b.setOnTouchListener { _, e -> when(e.action) {
            MotionEvent.ACTION_DOWN -> { sx=p.x; sy=p.y; tx=e.rawX; ty=e.rawY; true }
            MotionEvent.ACTION_MOVE -> { p.x=(sx-(e.rawX-tx).toInt()).coerceAtLeast(0); p.y=(sy+(e.rawY-ty).toInt()).coerceAtLeast(0); try { wm.updateViewLayout(b,p) } catch (_:Exception) {}; true }
            MotionEvent.ACTION_UP -> { if(kotlin.math.abs(e.rawX-tx)<dp(10) && kotlin.math.abs(e.rawY-ty)<dp(10)) togglePanel(); true }
            else -> false
        } }
        bubble=b
        try { wm.addView(b,p) } catch (_:Exception) { bubble=null; Toast.makeText(this,"Allow display over other apps to use AI Bot.",Toast.LENGTH_LONG).show(); stopSelf() }
    }

    private fun togglePanel() {
        if (panel != null) { removePanel(); return }
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(17),dp(16),dp(17),dp(16)); background=GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(20, 20, 57), Color.rgb(8, 60, 76))).apply { cornerRadius=dp(24).toFloat(); setStroke(dp(1), Color.rgb(74, 95, 174)) }; elevation=dp(12).toFloat() }
        val head=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text="✦  AI Bot"; textSize=21f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); layoutParams=LinearLayout.LayoutParams(0,dp(46),1f) })
        head.addView(TextView(this).apply { text="✕"; textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); contentDescription="Close menu"; layoutParams=LinearLayout.LayoutParams(dp(42),dp(42)); setOnClickListener { removePanel() } })
        root.addView(head)
        root.addView(TextView(this).apply { text="Your personal AI assistant"; textSize=13f; setTextColor(Color.rgb(145,177,211)); setPadding(0,0,0,dp(10)) })
        val scroll=ScrollView(this)
        val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        body.addView(section("QUICK ACTIONS"))
        body.addView(action("Understand Screen","Read visible text and explain it","◉") { understandScreen() })
        body.addView(action("Write Code","Speak a coding request","</>") { startListening() })
        body.addView(action("Build a Website","Generate a responsive HTML/CSS/JS website","🌐") { processPrompt("Help me create a complete responsive website. Provide a complete HTML file with CSS and JavaScript, ready to save and open in a browser.") })
        body.addView(action("Create & Save File","Generate code or text and save it to Downloads","📁") { processPrompt("Help me create a file. Ask what I need, then generate complete contents and offer to save the result.") })
        body.addView(action("Save Last Answer","Save the latest AI response as a file","💾") { saveLastAnswer() })
        body.addView(action("Browse Website","Speak a website or search term","◎") { startListening() })
        body.addView(action("Watch Videos","Open YouTube","▶") { openUrl("https://www.youtube.com") })
        body.addView(action("App Settings","Manage permissions and access","⚙") { openAppSettings() })
        body.addView(section("VOICE ASSISTANT"))
        answerView=TextView(this).apply { text="Hello! How can I help you today?"; textSize=14f; setTextColor(Color.rgb(239,245,255)); setPadding(dp(12),dp(12),dp(12),dp(12)); background=GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(39, 43, 100), Color.rgb(20, 77, 96))).apply { cornerRadius=dp(15).toFloat(); setStroke(dp(1), Color.rgb(62, 105, 166)) } }
        body.addView(answerView,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(9) })
        micButton=TextView(this).apply { text="🎙  Tap to Speak"; textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(0, 185, 255), Color.rgb(131, 60, 255))).apply { cornerRadius=dp(18).toFloat() }; setPadding(dp(12),dp(18),dp(12),dp(18)); contentDescription="Speak to AI Bot"; setOnClickListener { startListening() } }
        body.addView(micButton,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(TextView(this).apply { text="Speak in English or Hausa. AI Bot will answer aloud."; textSize=12f; gravity=Gravity.CENTER; setTextColor(Color.rgb(145,177,211)); setPadding(0,0,0,dp(8)) })
        val params=WindowManager.LayoutParams((resources.displayMetrics.widthPixels*.88f).toInt(),(resources.displayMetrics.heightPixels*.82f).toInt(),overlayType(),WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.END or Gravity.CENTER_VERTICAL; x=dp(6); softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
        panel=root
        try { wm.addView(root,params) } catch (_:Exception) { panel=null; Toast.makeText(this,"Enable Display over other apps for AI Bot.",Toast.LENGTH_LONG).show() }
    }
    private fun section(s:String)=TextView(this).apply { text=s; textSize=11f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(94,183,255)); setPadding(dp(2),dp(12),0,dp(8)) }
    private fun action(title:String,detail:String,glyph:String,run:()->Unit):View {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; background=GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35, 37, 88), Color.rgb(16, 66, 85))).apply { cornerRadius=dp(14).toFloat(); setStroke(dp(1), Color.argb(85, 120, 160, 255)) }; setPadding(dp(10),dp(9),dp(9),dp(9)); isClickable=true; isFocusable=true }
        row.addView(TextView(this).apply { text=glyph; textSize=20f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); layoutParams=LinearLayout.LayoutParams(dp(42),dp(42)) })
        val labels=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        labels.addView(TextView(this).apply { text=title; textSize=14f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        labels.addView(TextView(this).apply { text=detail; textSize=11f; setTextColor(Color.rgb(175,195,220)) })
        row.addView(labels,LinearLayout.LayoutParams(0,-2,1f)); row.setOnClickListener { run() }
        return row.apply { layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(7) } }
    }
    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            answerView?.text = "Speech recognition is not available on this device."
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            answerView?.text = "Allow microphone permission for AI Bot, then try speaking again."
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true; micButton?.text = "Listening… speak now"; answerView?.text = "I'm listening. Speak in English or Hausa." }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { listening = false; micButton?.text = "🎙  Tap to Speak" }
                    override fun onError(error: Int) { listening = false; micButton?.text = "🎙  Tap to Speak"; answerView?.text = "I couldn't hear that clearly. Tap the microphone and try again." }
                    override fun onResults(results: android.os.Bundle?) {
                        listening = false; micButton?.text = "🎙  Tap to Speak"
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        if (spoken.isNotBlank()) processPrompt(spoken) else answerView?.text = "No speech detected. Please try again."
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-NG")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-NG")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AI Bot")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) { answerView?.text = "Couldn't start voice input: ${e.message ?: "try again"}" }
    }

    private fun processPrompt(prompt: String) {
        val q = prompt.trim()
        if (q.isBlank()) return
        answerView?.text = "You said: $q\n\nThinking…"
        val lower = q.lowercase(Locale.ROOT)
        if (lower.contains("go back") || lower.contains("press back") || lower.contains("koma baya") || lower == "back") {
            val service = ScreenAccessibilityService.instance
            val ok = service?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) ?: false
            val msg = if (ok) "Going back one screen." else "Enable AI Bot under Accessibility settings to use the Back action."
            answerView?.text = msg; lastAnswer = msg; speak(msg); return
        }
        // Explicit, user-spoken accessibility commands. Actions only target the active screen.
        val accessibility = ScreenAccessibilityService.instance
        if (lower.startsWith("tap ") || lower.startsWith("click ") || lower.startsWith("danna ")) {
            val label = q.substringAfter(' ').trim()
            val ok = if (label.isNotBlank()) accessibility?.clickVisibleLabel(label) ?: false else false
            val msg = if (ok) "Na danna abin da ka nema: $label" else "Ban iya danna '$label' ba. Tabbatar yana bayyane kuma an kunna izinin Accessibility."
            answerView?.text = msg; lastAnswer = msg; speak(msg); return
        }
        if (lower.startsWith("type ") || lower.startsWith("rubuta ")) {
            val value = q.substringAfter(' ').trim()
            val ok = if (value.isNotBlank()) accessibility?.typeIntoFocusedField(value) ?: false else false
            val msg = if (ok) "Na rubuta abin da ka faɗa a filin da aka zaɓa." else "Ba a samu filin rubutu da aka zaɓa ba. Ka fara taɓa filin da kake son rubutawa."
            answerView?.text = msg; lastAnswer = msg; speak(msg); return
        }
        if (lower.contains("scroll down") || lower.contains("gungura ƙasa") || lower.contains("gungura kasa")) {
            val ok = accessibility?.scrollScreen(true) ?: false
            val msg = if (ok) "Na gungura ƙasa." else "Ba a samu abin gungurawa a allon ba."
            answerView?.text = msg; lastAnswer = msg; speak(msg); return
        }
        if (lower.contains("scroll up") || lower.contains("gungura sama")) {
            val ok = accessibility?.scrollScreen(false) ?: false
            val msg = if (ok) "Na gungura sama." else "Ba a samu abin gungurawa a allon ba."
            answerView?.text = msg; lastAnswer = msg; speak(msg); return
        }
        if (lower.contains("understand screen") || lower.contains("read my screen") || lower.contains("karanta allon")) { understandScreen(); return }
        if (lower.startsWith("open youtube") || lower.contains("watch videos")) { openUrl("https://www.youtube.com"); val msg="Opening YouTube."; answerView?.text=msg; speak(msg); return }
        if (lower.startsWith("open ") && (lower.contains(".com") || lower.contains("website"))) {
            val candidate = q.substringAfter("open ", "").replace(" website", "").trim()
            openUrl(if (candidate.startsWith("http")) candidate else "https://$candidate"); val msg="Opening $candidate."; answerView?.text=msg; speak(msg); return
        }
        if (!GeminiClient.hasApiKey(this)) {
            val msg = "Your request was heard, but AI replies are not enabled yet. Open AI Bot Settings and add your Gemini API key."
            answerView?.text = "$q\n\n$msg"; speak(msg); return
        }
        if (busy) return
        busy = true
        GeminiClient.ask(this, "You are AI Bot, a practical coding and website-building assistant. The user's spoken request is: $q. If asked to build a website, return a complete responsive HTML document with embedded CSS and JavaScript when appropriate, with clear instructions to save it as index.html and open it in a browser. If asked for code, provide complete usable code and specify filenames. If asked to create a feature or application, propose an implementable project structure and code. Never claim you have edited an external app or saved a file unless that action really happened. Ask for clarification when requirements are unclear and ask confirmation before consequential actions.") { result ->
            answerView?.post { answerView?.text = result; lastAnswer = result; busy = false; speak(result) } ?: run { busy = false }
        }
    }

    private fun saveLastAnswer() {
        val content = lastAnswer.ifBlank { answerView?.text?.toString().orEmpty() }
        if (content.isBlank() || content.contains("Thinking…")) {
            Toast.makeText(this, "There is no answer to save yet. Ask AI Bot to create a file first.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val html = content.contains("<html", ignoreCase = true) || content.contains("<!doctype html", ignoreCase = true)
            val name = if (html) "ai-bot-website-${System.currentTimeMillis()}.html" else "ai-bot-note-${System.currentTimeMillis()}.txt"
            val destinationDescription: String
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, if (html) "text/html" else "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri == null) { Toast.makeText(this, "Couldn't create the file. Please try again.", Toast.LENGTH_LONG).show(); return }
                contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                destinationDescription = "Downloads"
            } else {
                val folder = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
                folder.mkdirs()
                java.io.File(folder, name).writeText(content, Charsets.UTF_8)
                destinationDescription = folder.absolutePath
            }
            val msg = "Saved $name to $destinationDescription."
            answerView?.text = msg
            speak(msg)
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun speak(text: String) {
        val safe = text.take(3500)
        try { tts?.speak(safe, TextToSpeech.QUEUE_FLUSH, null, "ai-bot-response") } catch (_: Exception) {}
    }

    private fun understandScreen() {
        val snapshot=ScreenAccessibilityService.readCurrentScreen()
        if(snapshot==null){ Toast.makeText(this,"Enable AI Bot in Accessibility settings, then reopen the floating menu.",Toast.LENGTH_LONG).show(); try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_:Exception) {}; return }
        val prompt="Explain the content currently visible on my screen. Be concise and do not assume information not shown. Visible screen text:\n$snapshot"
        if(!GeminiClient.hasApiKey(this)) answerView?.text="Screen text captured:\n$snapshot\n\nAdd your Gemini API key in AI Bot Settings to let AI Bot explain it."
        else { answerView?.text="Reading the screen..."; GeminiClient.ask(this, prompt) { result -> answerView?.post { answerView?.text=result } } }
    }
    private fun openBrowser() { startListening() }
    private fun openUrl(url:String){ try { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch(_:Exception){ Toast.makeText(this,"No compatible browser app was found.",Toast.LENGTH_SHORT).show() } }
    private fun openAppSettings(){ try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch(_:Exception){} }
    private fun removePanel(){ panel?.let { try { wm.removeView(it) } catch(_:Exception){} }; panel=null; answerView=null; micButton=null; busy=false }
    override fun onDestroy(){ speechRecognizer?.destroy(); speechRecognizer=null; tts?.stop(); tts?.shutdown(); tts=null; removePanel(); bubble?.let { try { wm.removeView(it) } catch(_:Exception){} }; bubble=null; super.onDestroy() }
}
