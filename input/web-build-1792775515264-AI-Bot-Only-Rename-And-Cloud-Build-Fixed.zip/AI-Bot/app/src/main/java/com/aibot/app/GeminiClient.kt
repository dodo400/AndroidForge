package com.aibot.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Gemini client with Google Search grounding enabled for up-to-date answers. */
object GeminiClient {
    private const val PREFS = "ai_bot_settings"
    private const val KEY = "gemini_api_key"

    fun getApiKey(context: android.content.Context): String =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString(KEY, "").orEmpty().ifBlank { BuildConfig.GEMINI_API_KEY }

    fun hasApiKey(context: android.content.Context): Boolean = getApiKey(context).isNotBlank()

    fun saveApiKey(context: android.content.Context, key: String) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString(KEY, key.trim()).apply()
    }

    fun clearApiKey(context: android.content.Context) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun ask(context: android.content.Context, prompt: String, callback: (String) -> Unit) {
        thread(name = "GeminiClient") {
            var connection: HttpURLConnection? = null
            val result = try {
                val apiKey = getApiKey(context)
                if (apiKey.isBlank()) {
                    "Ba a saita Gemini API key ba tukuna. / Gemini API key has not been configured yet."
                } else {
                    val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"
                    connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 20000
                        readTimeout = 45000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    }

                    val instruction = "You are AI Bot, a helpful bilingual assistant. Reply in the same language the user uses; support Hausa and English. Use Google Search when current facts, news, prices, or web research would improve the answer. Be honest about uncertainty. When Search grounding is used, explain the findings clearly and include relevant source links provided by the tool. User request: $prompt"
                    val contents = JSONArray().put(
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction)))
                    )
                    val tools = JSONArray().put(JSONObject().put("google_search", JSONObject()))
                    val body = JSONObject().put("contents", contents).put("tools", tools).toString()
                    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (status !in 200..299) {
                        "Gemini API error ($status): $raw"
                    } else {
                        val json = JSONObject(raw)
                        val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
                        val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
                        val answer = buildString {
                            if (parts != null) {
                                for (i in 0 until parts.length()) {
                                    val text = parts.optJSONObject(i)?.optString("text").orEmpty()
                                    if (text.isNotBlank()) {
                                        if (isNotEmpty()) append("\n")
                                        append(text)
                                    }
                                }
                            }
                        }.ifBlank { "Ba a samu amsa daga Gemini ba. Duba API key da haɗin intanet. / No response was received from Gemini. Check the API key and internet connection." }

                        val sources = mutableListOf<Pair<String, String>>()
                        val chunks = candidate?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                        if (chunks != null) {
                            for (i in 0 until chunks.length()) {
                                val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                                val uri = web.optString("uri").trim()
                                val title = web.optString("title").trim().ifBlank { uri }
                                if (uri.startsWith("https://") || uri.startsWith("http://")) {
                                    if (sources.none { it.second == uri }) sources.add(title to uri)
                                }
                            }
                        }
                        if (sources.isNotEmpty()) {
                            answer + "\n\nTushen bayanai / Sources:\n" + sources.take(5).joinToString("\n") { "• ${it.first}: ${it.second}" }
                        } else answer
                    }
                }
            } catch (e: Exception) {
                "Matsalar haɗin Gemini: ${e.message ?: "unknown error"}"
            } finally {
                connection?.disconnect()
            }
            callback(result)
        }
    }
}
