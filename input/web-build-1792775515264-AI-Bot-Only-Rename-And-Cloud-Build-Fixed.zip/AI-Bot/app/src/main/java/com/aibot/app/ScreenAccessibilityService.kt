package com.aibot.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle

/** Reads visible text only after the user explicitly chooses Understand Screen. */
class ScreenAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); activeService = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* No continuous collection. */ }
    override fun onInterrupt() {}

    fun getVisibleTextSnapshot(): String {
        val root = rootInActiveWindow ?: return "This screen could not be read."
        val lines = mutableListOf<String>()
        try { collectText(root, lines) } finally { root.recycle() }
        return lines.distinct().take(100).joinToString("\n").ifBlank { "No visible text was found." }
    }
    /** Clicks a visible, clickable control whose label contains the requested text. */
    fun clickVisibleLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return try { findAndClick(root, label.trim().lowercase()) } finally { root.recycle() }
    }
    private fun findAndClick(node: AccessibilityNodeInfo, label: String): Boolean {
        val text = (node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")
        if (text.lowercase().contains(label) && node.isEnabled && node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val done = try { findAndClick(child, label) } finally { child.recycle() }
            if (done) return true
        }
        return false
    }
    /** Enters text only into the currently focused editable field. */
    fun typeIntoFocusedField(value: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return try { findFocusedEditable(root, value) } finally { root.recycle() }
    }
    private fun findFocusedEditable(node: AccessibilityNodeInfo, value: String): Boolean {
        if (node.isFocused && node.isEditable && node.isEnabled) {
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) })
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val done = try { findFocusedEditable(child, value) } finally { child.recycle() }
            if (done) return true
        }
        return false
    }
    fun scrollScreen(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        return try { scrollNode(root, forward) } finally { root.recycle() }
    }
    private fun scrollNode(node: AccessibilityNodeInfo, forward: Boolean): Boolean {
        if (node.isScrollable && node.isEnabled) {
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (node.performAction(action)) return true
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val done = try { scrollNode(child, forward) } finally { child.recycle() }
            if (done) return true
        }
        return false
    }
    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try { collectText(child, out) } finally { child.recycle() }
        }
    }
    override fun onDestroy() { if (activeService === this) activeService = null; super.onDestroy() }
    companion object {
        @Volatile private var activeService: ScreenAccessibilityService? = null
        val instance: ScreenAccessibilityService? get() = activeService
        fun readCurrentScreen(): String? = activeService?.getVisibleTextSnapshot()
    }
}
